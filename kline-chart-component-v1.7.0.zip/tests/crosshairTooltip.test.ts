/**
 * crosshairTooltip.test.ts —— 十字星数据浮层测试（v1.6.35）
 *
 * 覆盖：九行组装（时间/开盘/收盘/最高/最低/涨跌/涨幅/成交量/成交额）、
 * 红涨绿跌着色、涨跌基准（昨收）、缺失昨收兜底、量额格式化。
 */
import { describe, expect, it } from 'vitest'
import { buildTooltipRows, resolveTooltipPosition, clampTooltipPosition } from '../src/chart/crosshair/crosshairTooltip'
import type { ChartDataPoint } from '../src/types/chart'

const colors = { up: '#FF0000', down: '#008000' }

const makeBar = (partial: Partial<ChartDataPoint>): ChartDataPoint => ({
  time: 1728000000,
  tradeDate: '2024-10-04',
  preClose: 10,
  open: 10.2,
  high: 10.5,
  low: 10.1,
  close: 10.4,
  volume: 12345678,
  amount: 128000000,
  pointType: 'kline',
  ...partial,
})

describe('buildTooltipRows', () => {
  it('九行齐全且顺序正确', () => {
    const rows = buildTooltipRows(makeBar({}), '2024-10-04', colors)
    // v1.6.44：第一行时间直显，label 为空（不显示"时间"汉字）
    expect(rows.map((r) => r.label)).toEqual([
      '', '开盘', '收盘', '最高', '最低', '涨跌', '涨幅', '成交量', '成交额',
    ])
  })

  it('时间文本按 pane0 格式原样透传', () => {
    const rows = buildTooltipRows(makeBar({}), '2024-10-04 10:30', colors)
    expect(rows[0].value).toBe('2024-10-04 10:30')
  })

  it('涨红：close > preClose 时涨跌/涨幅为正并着上涨色', () => {
    const rows = buildTooltipRows(makeBar({ preClose: 10, close: 10.4 }), 't', colors)
    expect(rows[5].value).toBe('+0.40')
    expect(rows[5].color).toBe('#FF0000')
    expect(rows[6].value).toBe('+4.00%')
    expect(rows[6].color).toBe('#FF0000')
  })

  it('跌绿：close < preClose 时涨跌/涨幅为负并着下跌色', () => {
    const rows = buildTooltipRows(makeBar({ preClose: 10, close: 9.6 }), 't', colors)
    expect(rows[5].value).toBe('-0.40')
    expect(rows[5].color).toBe('#008000')
    expect(rows[6].value).toBe('-4.00%')
    expect(rows[6].color).toBe('#008000')
  })

  it('平盘：close == preClose 时不带符号不着色', () => {
    const rows = buildTooltipRows(makeBar({ preClose: 10, close: 10 }), 't', colors)
    expect(rows[5].value).toBe('0.00')
    expect(rows[5].color).toBeUndefined()
    expect(rows[6].value).toBe('0.00%')
  })

  it('开盘/收盘/最高/最低：高于昨收着上涨色（红）', () => {
    const rows = buildTooltipRows(makeBar({}), 't', colors) // preClose 10：open 10.2 / close 10.4 / high 10.5 / low 10.1
    expect(rows[1].color).toBe('#FF0000')
    expect(rows[2].color).toBe('#FF0000')
    expect(rows[3].color).toBe('#FF0000')
    expect(rows[4].color).toBe('#FF0000')
  })

  it('开盘/收盘/最高/最低：低于昨收着下跌色（绿）', () => {
    const rows = buildTooltipRows(makeBar({ open: 9.8, high: 9.9, low: 9.5, close: 9.6 }), 't', colors)
    expect(rows[1].color).toBe('#008000')
    expect(rows[2].color).toBe('#008000')
    expect(rows[3].color).toBe('#008000')
    expect(rows[4].color).toBe('#008000')
  })

  it('开盘/收盘/最高/最低：等于昨收不着色', () => {
    const rows = buildTooltipRows(makeBar({ open: 10, high: 10, low: 10, close: 10 }), 't', colors)
    expect(rows[1].color).toBeUndefined()
    expect(rows[2].color).toBeUndefined()
    expect(rows[3].color).toBeUndefined()
    expect(rows[4].color).toBeUndefined()
  })

  it('缺失昨收时以开盘点兜底（不抛错）', () => {
    const rows = buildTooltipRows(makeBar({ preClose: undefined, open: 10, close: 10.5 }), 't', colors)
    expect(rows[5].value).toBe('+0.50')
    expect(rows[6].value).toBe('+5.00%')
  })

  it('量额格式化：万 / 亿', () => {
    const rows = buildTooltipRows(
      makeBar({ volume: 12345678, amount: 128000000 }),
      't', colors,
    )
    expect(rows[7].value).toBe('1234.57万')
    expect(rows[8].value).toBe('1.28亿')
  })

  it('OHLC 缺失安全（undefined → --）', () => {
    const rows = buildTooltipRows(
      makeBar({ open: undefined, high: undefined, low: undefined }),
      't', colors,
    )
    expect(rows[1].value).toBe('--')
    expect(rows[3].value).toBe('--')
    expect(rows[4].value).toBe('--')
  })
})

describe('buildTooltipRows 分时点（v1.7.0）', () => {
  const makeTs = (partial: Partial<ChartDataPoint>): ChartDataPoint => ({
    time: 1728000000,
    tradeDate: '2024-10-04',
    preClose: 10,
    price: 10.4,
    avgPrice: 10.3,
    volume: 12345678,
    amount: 128000000,
    pointType: 'timeshare',
    ...partial,
  })

  it('七行齐全：时间 / 价格 / 均价 / 涨跌 / 涨幅 / 成交量 / 成交额', () => {
    const rows = buildTooltipRows(makeTs({}), '2024-10-04 09:35', colors)
    expect(rows.map((row) => row.label)).toEqual(['', '价格', '均价', '涨跌', '涨幅', '成交量', '成交额'])
    expect(rows[1].value).toBe('10.40')
    expect(rows[2].value).toBe('10.30')
    expect(rows[3].value).toBe('+0.40')
    expect(rows[4].value).toBe('+4.00%')
  })

  it('价格高于昨收红 / 低于昨收绿 / 平盘不着色', () => {
    expect(buildTooltipRows(makeTs({ price: 10.5 }), 't', colors)[1].color).toBe('#FF0000')
    expect(buildTooltipRows(makeTs({ price: 9.5 }), 't', colors)[1].color).toBe('#008000')
    expect(buildTooltipRows(makeTs({ price: 10 }), 't', colors)[1].color).toBeUndefined()
  })

  it('均价不着色；涨跌 / 涨幅随价格着色', () => {
    const rows = buildTooltipRows(makeTs({ price: 9.5 }), 't', colors)
    expect(rows[2].color).toBeUndefined()
    expect(rows[3].color).toBe('#008000')
    expect(rows[4].color).toBe('#008000')
  })

  it('成交量 / 成交额格式与 K 线一致（万 / 亿）', () => {
    const rows = buildTooltipRows(makeTs({}), 't', colors)
    expect(rows[5].value).toBe('1234.57万')
    expect(rows[6].value).toBe('1.28亿')
  })
})

describe('resolveTooltipPosition（v1.6.36 进入方向角落定位 / v1.6.58 限定 pane1~pane5 数据区）', () => {
  // 刻度全关：数据区 = 容器全宽（paneLeft 0 ~ paneRight 1000）
  const base = {
    paneTop: 22,
    tooltipWidth: 180,
    paneLeft: 0,
    paneRight: 1000,
  }

  it('左进入 → pane 右上角（数据区右缘 2px、pane 顶部 2px，v1.6.43）', () => {
    const pos = resolveTooltipPosition({ ...base, entrySide: 'left' })
    expect(pos).toEqual({ left: 1000 - 180 - 2, top: 24 })
  })

  it('右进入 → pane 左上角（数据区左缘 2px、pane 顶部 2px，v1.6.43）', () => {
    const pos = resolveTooltipPosition({ ...base, entrySide: 'right' })
    expect(pos).toEqual({ left: 2, top: 24 })
  })

  it('左进入（右上角）但浮层过宽 → clamp 到数据区左缘 2px（不越界）', () => {
    const pos = resolveTooltipPosition({
      ...base,
      entrySide: 'left',
      tooltipWidth: 1200,
    })
    expect(pos.left).toBe(2)
  })

  it('左右刻度打开：左进入 → 右上角在数据区右缘（不越右刻度区，v1.6.58）', () => {
    const pos = resolveTooltipPosition({
      ...base,
      paneLeft: 72, // 左刻度区宽
      paneRight: 1000 - 72, // 右刻度区宽 72
      entrySide: 'left',
    })
    expect(pos).toEqual({ left: 1000 - 72 - 180 - 2, top: 24 })
  })

  it('左右刻度打开：右进入 → 左上角在数据区左缘（不越左刻度区，v1.6.58）', () => {
    const pos = resolveTooltipPosition({
      ...base,
      paneLeft: 72,
      paneRight: 1000 - 72,
      entrySide: 'right',
    })
    expect(pos).toEqual({ left: 72 + 2, top: 24 })
  })

  it('仅右刻度打开：左进入 → 右上角按数据区右缘定位（v1.6.58）', () => {
    const pos = resolveTooltipPosition({
      ...base,
      paneLeft: 0,
      paneRight: 1000 - 72,
      entrySide: 'left',
    })
    expect(pos).toEqual({ left: 1000 - 72 - 180 - 2, top: 24 })
  })
})

describe('clampTooltipPosition（v1.6.59 拖动边界纯函数）', () => {
  // 容器原点 (100, 200)，数据区（相对容器）left 72 / right 928、top 22 / bottom 600
  const base = {
    bounds: { left: 72, right: 928, top: 22, bottom: 600 },
    containerLeft: 100,
    containerTop: 200,
    width: 180,
    height: 185,
  }
  // body 坐标 minLeft = 100+72+2 = 174；maxLeft = 100+928-180-2 = 846
  // minTop = 200+22+2 = 224；maxTop = 200+600-185-2 = 613

  it('在数据区内 → 原样返回（不 clamp）', () => {
    expect(clampTooltipPosition({ ...base, left: 400, top: 300 })).toEqual({ left: 400, top: 300 })
  })

  it('越过左刻度区 → clamp 到数据区左缘（174）', () => {
    expect(clampTooltipPosition({ ...base, left: 120, top: 300 }).left).toBe(174)
  })

  it('越过右刻度区 → clamp 到数据区右缘（846）', () => {
    expect(clampTooltipPosition({ ...base, left: 900, top: 300 }).left).toBe(846)
  })

  it('越过 pane1 顶 → clamp 到 pane1 顶（224）', () => {
    expect(clampTooltipPosition({ ...base, left: 400, top: 100 }).top).toBe(224)
  })

  it('越过 pane5 底 → clamp 到 pane5 底（613）', () => {
    expect(clampTooltipPosition({ ...base, left: 400, top: 900 }).top).toBe(613)
  })

  it('数据区比浮层小（极端）→ 取最小边界不出界', () => {
    const tiny = { left: 0, right: 100, top: 0, bottom: 50 }
    const pos = clampTooltipPosition({
      bounds: tiny,
      containerLeft: 0,
      containerTop: 0,
      width: 200,
      height: 185,
      left: 999,
      top: 999,
    })
    expect(pos.left).toBe(2) // max(minLeft=2, maxLeft=-202) → 2
    expect(pos.top).toBe(2)
  })
})
